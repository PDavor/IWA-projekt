<!DOCTYPE html>
	<html lang="hr">
		<head>
			<meta charset="UTF-8" />
			<meta name="author" content="Davor Pernjek" />
			<meta name="date" content="4.6.2020." />
			<link rel="stylesheet" href="stil.css" type="text/css" />